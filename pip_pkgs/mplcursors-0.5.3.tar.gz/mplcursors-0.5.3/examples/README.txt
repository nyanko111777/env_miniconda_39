.. _examples:

:mod:`mplcursors` examples
==========================

As `mplcursors` is fundamentally a library for interactivity, you should
download the examples and try them yourself :-)

.. vim: ft=rst
