:orphan:

mplcursors
==========

.. toctree::
   :maxdepth: 4

   mplcursors
