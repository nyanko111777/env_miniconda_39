TODO
----

- [ ] traceback should show in which plumbing class we are, not something inside
  the plumber. yafowil is doing it. jensens: would you be so kind.

- [X] verify behaviour with pickling in tests within plumber.
  (see ``node.ext.zodb`` -> no issues occurred)

- [X] verify behaviour with ZODB persistence in tests within plumber.
  (see ``node.ext.zodb`` -> no issues occurred)

- [X] subclassing for plumbing behaviors.

- [ ] mature plumbing of properties.

- [ ] py26 @foo.setter support in all decorators.
