from .main import FontAwesomePattern, FontAwesomeExtension, FontAwesomeException, makeExtension  # NOQA
