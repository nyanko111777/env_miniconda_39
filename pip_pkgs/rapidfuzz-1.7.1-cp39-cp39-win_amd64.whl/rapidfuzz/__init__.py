"""
rapid string matching library
"""
__author__ = "Max Bachmann"
__license__ = "MIT"
__version__ = "1.7.1"

from rapidfuzz import process, fuzz, utils, levenshtein, string_metric
